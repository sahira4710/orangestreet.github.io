const products = [
  {id:'o-asahi', title:'Orange', artist:'Asahi', price:300000, img:'assets/orange-cover.svg'}
];

const cartKey = 'orangeStreetCart';
let cart = JSON.parse(localStorage.getItem(cartKey) || '{}');

const grid = document.getElementById('productGrid');
const cartCount = document.getElementById('cartCount');
const cartDrawer = document.getElementById('cartDrawer');
const cartItemsEl = document.getElementById('cartItems');
const cartTotalEl = document.getElementById('cartTotal');
const backdrop = document.getElementById('backdrop');
const searchInput = document.getElementById('searchInput');

function formatRupiah(num){ return num.toLocaleString('id-ID', {style:'currency', currency:'IDR', maximumFractionDigits:0}); }
function saveCart(){ localStorage.setItem(cartKey, JSON.stringify(cart)); renderCartBadge(); }

function addToCart(id, qty=1){
  cart[id] = (cart[id]||0) + qty;
  saveCart(); renderCart();
}

function setQty(id, qty){
  if(qty <= 0) delete cart[id]; else cart[id] = qty;
  saveCart(); renderCart();
}
function removeFromCart(id){ delete cart[id]; saveCart(); renderCart(); }

function cartItems(){ return Object.entries(cart).map(([id,qty])=>{ const p = products.find(x=>x.id===id); return {...p, qty, line: p.price*qty}; }); }

function renderCartBadge(){ const count = Object.values(cart).reduce((a,b)=>a+(b||0),0); cartCount.textContent = count; }

function openCart(){ cartDrawer.classList.add('open'); cartDrawer.setAttribute('aria-hidden','false'); backdrop.hidden=false; }
function closeCart(){ cartDrawer.classList.remove('open'); cartDrawer.setAttribute('aria-hidden','true'); backdrop.hidden=true; }

function renderCart(){
  const items = cartItems();
  cartItemsEl.innerHTML = items.length? '' : '<p>Keranjang kosong.</p>';
  for(const it of items){
    const row = document.createElement('div'); row.className='cart-item';
    row.innerHTML = `
      <img src="${it.img}" alt="cover ${it.title}"/>
      <div>
        <div style="font-weight:700">${it.title}</div>
        <div style="color:#8B7D72">${it.artist}</div>
        <div style="font-weight:700; color:var(--orange-deep)">${formatRupiah(it.price)}</div>
      </div>
      <div style="display:grid; gap:6px; align-items:center; justify-items:end">
        <div style="display:flex; gap:6px; align-items:center">
          <button class="icon-btn" data-action="dec">−</button>
          <span>${it.qty}</span>
          <button class="icon-btn" data-action="inc">＋</button>
        </div>
        <button class="icon-btn" data-action="del">🗑</button>
      </div>
    `;
    row.querySelector('[data-action="dec"]').onclick = ()=> setQty(it.id, it.qty-1);
    row.querySelector('[data-action="inc"]').onclick = ()=> setQty(it.id, it.qty+1);
    row.querySelector('[data-action="del"]').onclick = ()=> removeFromCart(it.id);
    cartItemsEl.appendChild(row);
  }
  const total = items.reduce((s,i)=>s+i.line,0);
  cartTotalEl.textContent = formatRupiah(total);
  renderCartBadge();
}

function renderProducts(list){
  grid.innerHTML = '';
  for(const p of list){
    const card = document.createElement('article'); card.className='card';
    card.innerHTML = `
      <img class="thumb" src="${p.img}" alt="Sampul ${p.title}"/>
      <div class="meta">
        <div class="title">${p.title}</div>
        <div class="artist">${p.artist}</div>
        <div class="price">${formatRupiah(p.price)}</div>
      </div>
      <div class="controls">
        <div class="qty">
          <button class="btn qty-dec">−</button>
          <input type="number" min="1" value="1" aria-label="Jumlah"/>
          <button class="btn qty-inc">＋</button>
        </div>
        <button class="btn add-btn">Tambah</button>
      </div>
    `;
    const qtyInput = card.querySelector('input');
    card.querySelector('.qty-dec').onclick = ()=> qtyInput.value = Math.max(1, parseInt(qtyInput.value||'1')-1);
    card.querySelector('.qty-inc').onclick = ()=> qtyInput.value = parseInt(qtyInput.value||'1')+1;
    card.querySelector('.add-btn').onclick = ()=> addToCart(p.id, parseInt(qtyInput.value||'1'));
    grid.appendChild(card);
  }
}

searchInput.addEventListener('input', ()=> applySearch());
function applySearch(){
  const q = (searchInput.value||'').toLowerCase().trim();
  let list = products.filter(p=> p.title.toLowerCase().includes(q) || p.artist.toLowerCase().includes(q));
  renderProducts(list);
}

document.getElementById('cartButton').addEventListener('click', openCart);
document.getElementById('closeCart').addEventListener('click', closeCart);
document.getElementById('checkoutBtn').addEventListener('click', ()=>{
  const items = cartItems();
  if(!items.length){ alert('Keranjang kosong.'); return; }
  alert('Checkout demo — terima kasih!');
  cart = {}; saveCart(); renderCart();
});
backdrop.addEventListener('click', closeCart);

// init
document.getElementById('year').textContent = new Date().getFullYear();
renderProducts(products);
renderCart();
applySearch();
