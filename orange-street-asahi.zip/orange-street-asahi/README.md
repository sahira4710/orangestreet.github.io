# Orange Street — Single Album Demo (Orange by Asahi)

Demo situs untuk album "Orange" karya Asahi. Tema oranye + krem, desain minimalis.
Fitur: daftar album, gambar sampul (SVG), harga, keranjang berbasis localStorage.

## Cara pakai
- Ekstrak ZIP.
- Buka index.html di browser untuk melihat lokal.
- Untuk GitHub Pages: buat repo, upload file ke branch `main`, Settings → Pages → deploy from branch `main` (root /).

Harga album sudah di-set Rp300.000.
